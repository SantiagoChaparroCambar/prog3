/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/**
 *
 * @author Estudiante
 */
public class CarreraAuto {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
